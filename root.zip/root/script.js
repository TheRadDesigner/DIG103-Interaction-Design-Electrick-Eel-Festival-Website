$(".hamburgericon").on("click", function(){
  $(".menu").toggleClass("menu-open");
});

$(".alt-hamburger").on("click", function(){
  $(".alt-menu").toggleClass("alt-menu-open");
});
